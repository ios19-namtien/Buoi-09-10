//
//  main.m
//  BicycleYamaha
//
//  Created by NguyenTien on 1/14/14.
//  Copyright (c) 2014 NguyenTien. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
