//
//  Bicycle.h
//  BicycleYamaha
//
//  Created by NguyenTien on 1/14/14.
//  Copyright (c) 2014 NguyenTien. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Bicycle : UIView

@property (nonatomic, strong) NSString *BicyclePicture;
@property (nonatomic, strong) NSString *BicycleName;
@property (nonatomic, strong) NSString *BicycleManufacturer;
@property (nonatomic, strong) NSString *BicycleState;
@property (nonatomic, strong) NSString *BicyclePrice;




@end
