//
//  AppDelegate.h
//  BicycleYamaha
//
//  Created by NguyenTien on 1/14/14.
//  Copyright (c) 2014 NguyenTien. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
